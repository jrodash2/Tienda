from django.contrib import admin
from .models import CategoriaProducto, MarcaProducto, Producto, ImagenProducto, ClientePedido, Pedido, DetallePedido, CuentaBancaria, UbicacionTienda, Cliente, Venta, DetalleVenta, PagoVenta


class ImagenProductoInline(admin.TabularInline):
    model = ImagenProducto
    extra = 1
    fields = ('imagen', 'alt', 'orden', 'principal', 'activo')


@admin.register(CategoriaProducto)
class CategoriaProductoAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'slug', 'activo', 'orden', 'fecha_creacion')
    list_filter = ('activo',)
    search_fields = ('nombre', 'descripcion')
    prepopulated_fields = {'slug': ('nombre',)}


@admin.register(MarcaProducto)
class MarcaProductoAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'slug', 'activo')
    list_filter = ('activo',)
    search_fields = ('nombre',)
    prepopulated_fields = {'slug': ('nombre',)}


@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ('codigo_sku', 'nombre', 'categoria', 'marca', 'precio_costo', 'precio', 'precio_oferta', 'ganancia_unitaria', 'margen_ganancia', 'stock', 'activo', 'destacado')
    list_filter = ('activo', 'destacado', 'nuevo', 'permite_compra', 'categoria', 'marca')
    search_fields = ('nombre', 'codigo_sku', 'descripcion_corta')
    prepopulated_fields = {'slug': ('nombre',)}
    inlines = [ImagenProductoInline]


@admin.register(ImagenProducto)
class ImagenProductoAdmin(admin.ModelAdmin):
    list_display = ('producto', 'alt', 'orden', 'principal', 'activo', 'fecha_creacion')
    list_filter = ('principal', 'activo')
    search_fields = ('producto__nombre', 'alt')


class DetallePedidoInline(admin.TabularInline):
    model = DetallePedido
    extra = 0
    readonly_fields = ('producto', 'nombre_producto_snapshot', 'codigo_sku_snapshot', 'precio_unitario', 'precio_costo_unitario', 'cantidad', 'subtotal', 'costo_envio_unitario', 'costo_envio_total')


@admin.register(ClientePedido)
class ClientePedidoAdmin(admin.ModelAdmin):
    list_display = ('nombre_completo', 'telefono', 'email', 'departamento', 'municipio')
    search_fields = ('nombres', 'apellidos', 'telefono', 'email', 'nit')


@admin.register(Pedido)
class PedidoAdmin(admin.ModelAdmin):
    list_display = ('codigo_pedido', 'cliente', 'total', 'tipo_entrega', 'estado', 'estado_pago', 'metodo_pago', 'fecha_creacion')
    list_filter = ('tipo_entrega', 'estado', 'estado_pago', 'metodo_pago', 'fecha_creacion')
    search_fields = ('codigo_pedido', 'cliente__nombres', 'cliente__apellidos', 'cliente__email', 'cliente__telefono')
    readonly_fields = ('codigo_pedido', 'correo_confirmacion_enviado', 'fecha_correo_confirmacion', 'fecha_creacion', 'fecha_actualizacion')
    inlines = [DetallePedidoInline]


@admin.register(DetallePedido)
class DetallePedidoAdmin(admin.ModelAdmin):
    list_display = ('pedido', 'nombre_producto_snapshot', 'cantidad', 'precio_unitario', 'precio_costo_unitario', 'subtotal', 'ganancia_total', 'costo_envio_total')
    search_fields = ('pedido__codigo_pedido', 'nombre_producto_snapshot', 'codigo_sku_snapshot')


@admin.register(CuentaBancaria)
class CuentaBancariaAdmin(admin.ModelAdmin):
    list_display = ('banco', 'nombre_cuenta', 'numero_cuenta', 'tipo_cuenta', 'moneda', 'activo', 'orden')
    list_filter = ('activo', 'moneda')
    search_fields = ('banco', 'nombre_cuenta', 'numero_cuenta')


@admin.register(UbicacionTienda)
class UbicacionTiendaAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'departamento', 'municipio', 'telefono', 'activo', 'orden')
    list_filter = ('activo', 'departamento')
    search_fields = ('nombre', 'direccion', 'municipio', 'departamento')


class DetalleVentaInline(admin.TabularInline):
    model = DetalleVenta
    extra = 0
    readonly_fields = ('producto', 'cantidad', 'precio_unitario', 'precio_costo_unitario', 'subtotal', 'costo_total', 'ganancia_total')

class PagoVentaInline(admin.TabularInline):
    model = PagoVenta
    extra = 0
    readonly_fields = ('monto', 'metodo_pago', 'referencia', 'fecha', 'usuario', 'observaciones')

@admin.register(Cliente)
class ClienteAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'telefono', 'email', 'nit', 'dpi', 'fecha_creacion')
    search_fields = ('nombre', 'telefono', 'email', 'nit', 'dpi')

@admin.register(Venta)
class VentaAdmin(admin.ModelAdmin):
    list_display = ('id', 'cliente', 'origen', 'estado', 'total', 'total_pagado', 'saldo_pendiente', 'ganancia_total', 'fecha', 'usuario')
    list_filter = ('estado', 'origen', 'fecha')
    search_fields = ('cliente__nombre', 'cliente__telefono', 'cliente__nit')
    inlines = [DetalleVentaInline, PagoVentaInline]

@admin.register(DetalleVenta)
class DetalleVentaAdmin(admin.ModelAdmin):
    list_display = ('venta', 'producto', 'cantidad', 'precio_unitario', 'precio_costo_unitario', 'subtotal', 'ganancia_total')
    search_fields = ('venta__id', 'producto__nombre', 'producto__codigo_sku')

@admin.register(PagoVenta)
class PagoVentaAdmin(admin.ModelAdmin):
    list_display = ('venta', 'monto', 'metodo_pago', 'referencia', 'fecha', 'usuario')
    list_filter = ('metodo_pago', 'fecha')

from .models import CotizacionPOS, DetalleCotizacionPOS


class DetalleCotizacionPOSInline(admin.TabularInline):
    model = DetalleCotizacionPOS
    extra = 0
    readonly_fields = ('producto', 'cantidad', 'precio_unitario', 'precio_costo_unitario', 'subtotal', 'costo_total', 'ganancia_total')


@admin.register(CotizacionPOS)
class CotizacionPOSAdmin(admin.ModelAdmin):
    list_display = ('id', 'cliente', 'estado', 'total', 'fecha', 'fecha_vencimiento', 'usuario', 'venta_convertida')
    list_filter = ('estado', 'fecha')
    search_fields = ('id', 'cliente__nombre', 'cliente__telefono', 'cliente__nit', 'usuario__username')
    inlines = [DetalleCotizacionPOSInline]


@admin.register(DetalleCotizacionPOS)
class DetalleCotizacionPOSAdmin(admin.ModelAdmin):
    list_display = ('cotizacion', 'producto', 'cantidad', 'precio_unitario', 'precio_costo_unitario', 'subtotal', 'ganancia_total')
    search_fields = ('cotizacion__id', 'producto__nombre', 'producto__codigo_sku')
